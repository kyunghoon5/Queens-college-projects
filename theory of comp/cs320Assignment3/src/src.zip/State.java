//Theory of Computation - CSCI 320
//Assignment 3
//Ali Tavoli, Kyunghoon Oh

public class State {
    private int number;

    public State(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
